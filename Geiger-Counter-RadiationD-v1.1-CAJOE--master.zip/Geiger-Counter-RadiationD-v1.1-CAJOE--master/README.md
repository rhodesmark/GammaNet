# Geiger Counter

For ESP32 boards

Install in Arduino IDE:

IFTT library
Thinkspeak library 

Video: https://youtu.be/K28Az3-gV7E
